#!/bin/bash
while true; do /home/neon_pulse/neonpulse ; done
