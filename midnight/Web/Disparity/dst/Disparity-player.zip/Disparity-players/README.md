# Disparity

I only trust what I see and, guess what ?
I don't see any vulnerability in my app.







Flag : MCTF{b82189df59a7ff9eee7447e4feb78165}

